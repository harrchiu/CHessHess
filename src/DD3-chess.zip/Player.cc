#include "Player.h"
#include "Move.h"

//CTOR
Player::Player(PieceColour color ) : color{color} {}
//DTOR
Player::~Player(){}
